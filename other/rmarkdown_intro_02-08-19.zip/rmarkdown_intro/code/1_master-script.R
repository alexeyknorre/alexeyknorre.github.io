# Master script
# Alexey Knorre
# a.v.knorre@gmail.com

# Paper
library(rmarkdown)
render("./code/1_paper.Rmd", 
       output_dir = "./results/", output_file = paste0("paper_draft_",Sys.Date(),".docx"),
       encoding = "UTF-8", quiet = T, clean = T, envir = new.env())

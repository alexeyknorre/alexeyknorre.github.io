library(officer)
library(readxl)

# Preparing applications for the evaluation. Producing responses in Google Forms
# into Word docs and merging them with task solutions.

# Read responses data from CSV
responses <- read_xlsx("data/google_responses.xlsx")

# Data preprocessing
names(responses)
names(responses) <- c("datetime",
                      "last_name",
                      "first_name",
                      "patronimic_name",
                      "phone",
                      "email",
                      "birth_year",
                      "city",
                      "university",
                      "department",
                      "napravlenie",
                      "program",
                      "university_year",
                      "merits")

# Trim last names

responses$last_name <- trimws(responses$last_name)

# Date-time
responses$datetime <- as.character(as.POSIXlt(substr(responses$datetime,1,19),
                                 format = "%Y/%m/%d %H:%M:%S"))

# A function that produces Word docs with bio summary from Google Forms
compose_bio <- function(responses_row){
  print(responses_row$last_name)
  doc <- read_docx()
  # Add a title to the document
  doc <- body_add_par(doc, paste(responses_row$last_name,responses_row$first_name,
                                 responses_row$patronimic_name),
                      style = "heading 1")
  
  doc <- body_add_par(doc, "Информация о заявителе", style = "heading 2")
  doc <- body_add_par(doc, paste("Вуз: ",
                                 responses_row$university))
  doc <- body_add_par(doc, paste("Образование: ", 
                                 responses_row$department,
                                 responses_row$napravlenie,
                                 responses_row$program,
                                 "Курс:",responses_row$university_year
  ))
  doc <- body_add_par(doc, paste("Город: ", responses_row$city))
  doc <- body_add_par(doc, paste("Возраст: ", 2019 - responses_row$birth_year))
  
  doc <- body_add_par(doc, paste("Телефон: ", responses_row$phone))
  doc <- body_add_par(doc, paste("Email: ", responses_row$email))
  
  # Add texts
  doc <- body_add_par(doc, "Достижения", style = "heading 2") 
  doc <- body_add_par(doc, responses_row$merits)
  # Create dir
  dir.create(file.path("results/officer", responses_row$last_name))
  
  # Write the Word document to a file 
  path <- paste0("results/officer/",responses_row$last_name,"//",
                    paste0(responses_row$last_name,"_bio.docx"))
  
  print(doc, target = path)
}


# For some reason Word document sometimes isn't saved, returning an error.
# Below is an wrapper that repeats it until success
for (i in 1:nrow(responses)) {
  while(TRUE){
    r <- try(compose_bio(responses[i,]))
    if(!is(r, 'try-error')) break
  }
}

